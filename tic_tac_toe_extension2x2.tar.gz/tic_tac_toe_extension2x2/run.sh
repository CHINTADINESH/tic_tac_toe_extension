#!bin/bash
make v_fname=tttg

